#!/bin/bash

cp -R /home/ignamv/programacion/kicad_scripts/rfid_calculator/* /home/spiralinductor/app
