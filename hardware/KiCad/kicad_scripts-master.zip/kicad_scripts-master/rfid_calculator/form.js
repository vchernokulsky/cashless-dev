$(document).ready(function() {
    $('<b>hola</b>').insertAfter('#units');
    alert('h0la');
})
